<div class="widget widget-latest-post">
    <div class="widget-title">
        <h3>Quick Actions</h3>
    </div>
    <div class="widget-body">
        <div class="latest-post-aside media">
            <div class="lpa-left media-body">
                <div class="lpa-title">
                    <h5><a href="<?php echo e(route('area.admin')); ?>">Properties</a></h5>
                </div>
            </div>
        </div>
        <div class="latest-post-aside media">
            <div class="lpa-left media-body">
                <div class="lpa-title">
                    <h5><a href="<?php echo e(route('admin.inspect')); ?>">List of Inspections</a></h5>
                </div>
            </div>
        </div>
        <div class="latest-post-aside media">
            <div class="lpa-left media-body">
                <div class="lpa-title">
                    <h5><a href="<?php echo e(route('admin.users')); ?>">Users</a></h5>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\JS_PROJECTS\DlinksPropertyProject\resources\views/partials/adminsidebar.blade.php ENDPATH**/ ?>