

<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid bg-dark bg-img p-5 mb-5">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="display-4 text-uppercase text-white">My Area</h1>
                <a href="">Home</a>
                <i class="far fa-square text-primary px-2"></i>
                <a href="">My Area</a>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- About Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="blog-single gray-bg">
                <div class="container">
                    <div class="row align-items-start">
                        <div class="col-lg-9 m-15px-tb">
                            <article class="article">
                                <div class="row">
                                    <?php $__currentLoopData = $props; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h3><?php echo e($item->property_name); ?></h3>
                                                    <p><?php echo e($item->property_type); ?> by <?php echo e($item->inspector); ?></p>
                                                    <p><?php echo e(date('d-F-Y g:i a', strtotime($item->inspection_date))); ?></p>
                                                    <?php if($item->isRequested): ?>
                                                        <p class="badge bg-warning">Pending request</p>
                                                    <?php else: ?>
                                                        <p class="badge bg-success">Request Accepted</p>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="card-footer">
                                                    <?php if($item->inspection_date != null): ?>
                                                        <a href="<?php echo e('https://wa.me/' . $item->inspect_url); ?>"
                                                            class="btn btn-primary">Connect
                                                            Now</a> |
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(url('paynow/' . $item->id)); ?>" class="btn btn-success">Pay
                                                        Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </article>

                        </div>
                        <div class="col-lg-3 m-15px-tb blog-aside">
                            <!-- Latest Post -->
                            <div class="widget widget-latest-post">
                                <div class="widget-title">
                                    <h3>Quick Actions</h3>
                                </div>
                                <div class="widget-body">
                                    <div class="latest-post-aside media">
                                        <div class="lpa-left media-body">
                                            <div class="lpa-title">
                                                <h5><a href="#">Book Inspect Properties</a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="latest-post-aside media">
                                        <div class="lpa-left media-body">
                                            <div class="lpa-title">
                                                <h5><a href="#">Inspected Properties</a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="latest-post-aside media">
                                        <div class="lpa-left media-body">
                                            <div class="lpa-title">
                                                <h5><a href="#">Paid Properties</a></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Latest Post -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- About End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JS_PROJECTS\DlinksPropertyProject\resources\views/area/myarea.blade.php ENDPATH**/ ?>