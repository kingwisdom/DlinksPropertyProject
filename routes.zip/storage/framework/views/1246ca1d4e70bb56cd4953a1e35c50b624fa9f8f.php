

<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid bg-dark bg-img p-5 mb-5">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="display-4 text-uppercase text-white">Area</h1>
                <a href="">Home</a>
                <i class="far fa-square text-primary px-2"></i>
                <a href="">My Area</a>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- About Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="blog-single gray-bg">
                <div class="row col-3">
                    <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary w-10">Create Property</a>
                </div>
                <div class="container">
                    <div class="row align-items-start">
                        <div class="col-lg-9 m-15px-tb">
                            <article class="article">
                                <div class="row">
                                    <?php $__currentLoopData = $props; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h3><?php echo e($item->name); ?></h3>
                                                    <p><?php echo e($item->type); ?> | #<?php echo e($item->price); ?></p>
                                                    <p><?php echo e($item->created_at); ?></p>
                                                </div>
                                                <div class="card-footer">
                                                    <a href="#" class="btn btn-primary">View</a>
                                                    <a href="<?php echo e(route('admin.delete')); ?>" class="btn btn-danger">Delete</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </article>

                        </div>
                        <div class="col-lg-3 m-15px-tb blog-aside">
                            <!-- Latest Post -->
                            <?php echo $__env->make('partials.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!-- End Latest Post -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- About End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JS_PROJECTS\DlinksPropertyProject\resources\views/area/admin_area.blade.php ENDPATH**/ ?>